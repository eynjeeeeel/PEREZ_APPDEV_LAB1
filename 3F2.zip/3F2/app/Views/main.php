<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Information</title>
    <style>
                body {
            font-family: "Times New Roman", Times, serif;
            background-color: beige; 
            margin: 0;
            padding: 0;
        }

        .header {
            background-color: #a68276; 
            color: white;
            text-align: center;
            padding: 20px 0;
        }

        .container {
            background-color: #f4dcd2; 
            margin: 20px;
            padding: 20px;
            border: 1px solid #d1b5a1; 
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

        form {
            max-width: 600px;
            margin: 0 auto;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }

        input[type="text"],
        select {
            width: 100%;
            padding: 8px;
            margin-bottom: 20px;
            border: 1px solid #d1b5a1; 
            border-radius: 4px;
            font-size: 16px;
        }

        select.form-control {
            padding: 8px;
        }

        input[type="submit"] {
            background-color: #a68276; 
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 18px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #d1b5a1; 
            padding: 10px;
            text-align: center;
        }

        th {
            background-color: #a68276; 
            color: white;
        }

        .action-links a {
            color: #a68276; 
            text-decoration: none;
            margin: 0 5px;
        }

        .action-links a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="header">
        <h1>Student Information</h1>
    </div>

    <div class="container">
        <div class="form-container">
            <form action="<?= base_url("save") ?>" method="post">
                <?php if (isset($d['id'])): ?>
                    <input type="hidden" name="id" value="<?= $d['id'] ?>">
                <?php endif; ?>

                <label for="StudID">Student ID:</label>
                <input type="text" id="StudID" name="StudID" required value="<?= isset($d['StudID']) ? $d['StudID'] : '' ?>">

                <label for="StudName">Name:</label>
                <input type="text" id="StudName" name="StudName" required value="<?= isset($d['StudName']) ? $d['StudName'] : '' ?>">

                <label for="StudGender">Gender:</label>
                <select id="StudGender" name="StudGender" required>
                <option value="" <?= isset($d['StudGender']) && $d['StudGender'] === '' ? 'selected' : '' ?>>SELECT GENDER</option>
                    <option value="MALE" <?= isset($d['StudGender']) && $d['StudGender'] === 'MALE' ? 'selected' : '' ?>>MALE</option>
                    <option value="FEMALE" <?= isset($d['StudGender']) && $d['StudGender'] === 'FEMALE' ? 'selected' : '' ?>>FEMALE</option>
                </select>

                <label for="StudCourse">Course:</label>
                <select class="form-control" id="StudCourse" name="StudCourse" required>
                    <optgroup>
                    <option value="" <?= isset($d['StudCourse']) && $d['StudCourse'] === '' ? 'selected' : '' ?>>STUDENT COURSE</option>
                        <option value="BSED Major in English" <?= isset($d['StudCourse']) && $d['StudCourse'] === 'BSED Major in English' ? 'selected' : '' ?>>BSED Major in English</option>
                        <option value="BSED Major in Math" <?= isset($d['StudCourse']) && $d['StudCourse'] === 'BSED Major in Math' ? 'selected' : '' ?>>BSED Major in Math</option>
                        <option value="BSED Major in Filipino" <?= isset($d['StudCourse']) && $d['StudCourse'] === 'BSED Major in Filipino' ? 'selected' : '' ?>>BSED Major in Filipino</option>
                        <option value="BSED Major in Science" <?= isset($d['StudCourse']) && $d['StudCourse'] === 'BSED Major in Science' ? 'selected' : '' ?>>BSED Major in Science</option>
                    </optgroup>

                    <optgroup label="">
                        <option value="BTVTED Major in Food Services Management" <?= isset($d['StudCourse']) && $d['StudCourse'] === 'BTVTED Major in Food Services Management' ? 'selected' : '' ?>>BTVTED Major in Food Services Management</option>
                        <option value="BTVTED Major in Automotive Technology" <?= isset($d['StudCourse']) && $d['StudCourse'] === 'BTVTED Major in Automotive Technology' ? 'selected' : '' ?>>BTVTED Major in Automotive Technology</option>
                        <option value="BTVTED Major in Electrical Technology" <?= isset($d['StudCourse']) && $d['StudCourse'] === 'BTVTED Major in Electrical Technology' ? 'selected' : '' ?>>BTVTED Major in Electrical Technology</option>
                        <option value="BTVTED Major in Electronics Technology" <?= isset($d['StudCourse']) && $d['StudCourse'] === 'BTVTED Major in Electronics Technology' ? 'selected' : '' ?>>BTVTED Major in Electronics Technology</option>
                        <option value="BTVTED Major in Drafting Technology" <?= isset($d['StudCourse']) && $d['StudCourse'] === 'BTVTED Major in Drafting Technology' ? 'selected' : '' ?>>BTVTED Major in Drafting Technology</option>
                        <option value="BTVTED Major in Garments and Fasion Design Technology" <?= isset($d['StudCourse']) && 
                        $d['StudCourse'] === 'BTVTED Major in Garments and Fasion Design Technology' ? 'selected' : '' ?>>BTVTED Major in Garments and Fasion Design Technology</option>
                    </optgroup>

                    <optgroup label="">
                    <option value="Bachelor of Science in Criminology" <?= isset($d['StudCourse']) && $d['StudCourse'] === 'Bachelor of Science in Criminology' ? 'selected' : '' ?>>Bachelor of Science in Criminology</option>
                    </optgroup>

                    <optgroup label="">
                    <option value="Bachelor of Arts in Psychology" <?= isset($d['StudCourse']) && $d['StudCourse'] === 'Bachelor of Arts in Psychology' ? 'selected' : '' ?>>Bachelor of Arts in Psychology</option>
                    </optgroup>

                    <optgroup label="">
                    <option value="Bachelor of Arts in English Language" <?= isset($d['StudCourse']) && $d['StudCourse'] === 'Bachelor of Arts in English Language' ? 'selected' : '' ?>>Bachelor of Arts in English Language</option>
                    </optgroup>

                    <optgroup label="">
                    <option value="Bachelor of Science in Information Technology" <?= isset($d['StudCourse']) && $d['StudCourse'] === 'Bachelor of Science in Information Technology' ? 'selected' : '' ?>>Bachelor of Science in Information Technology</option>
                    </optgroup>

                    <optgroup label="">
                    <option value="Bachelor of Science in Hospitality Management" <?= isset($d['StudCourse']) && $d['StudCourse'] === 'Bachelor of Science in Hospitality Management' ? 'selected' : '' ?>>Bachelor of Science in Hospitality Management</option>
                    </optgroup>

                    <optgroup label="">
                    <option value="Bachelor of Science in Tourism Management" <?= isset($d['StudCourse']) && $d['StudCourse'] === 'Bachelor of Science in Tourism Management' ? 'selected' : '' ?>>Bachelor of Science in Tourism Management</option>
                    </optgroup>

                    <optgroup label=""></optgroup>
                </select>

                <label for="StudSection">Section:</label>
                <select class="form-control" id="StudSection" name="StudSection" required>
                    <option value="" <?= isset($d['StudSection']) && $d['StudSection'] === '' ? 'selected' : '' ?>>CLASS</option>
                    <option value="F1" <?= isset($d['StudSection']) && $d['StudSection'] === 'F1' ? 'selected' : '' ?>>F1</option>
                    <option value="F2" <?= isset($d['StudSection']) && $d['StudSection'] === 'F2' ? 'selected' : '' ?>>F2</option>
                    <option value="F3" <?= isset($d['StudSection']) && $d['StudSection'] === 'F3' ? 'selected' : '' ?>>F3</option>
                    <option value="F4" <?= isset($d['StudSection']) && $d['StudSection'] === 'F4' ? 'selected' : '' ?>>F4</option>
                    <option value="F5" <?= isset($d['StudSection']) && $d['StudSection'] === 'F5' ? 'selected' : '' ?>>F5</option>
                    <option value="F6" <?= isset($d['StudSection']) && $d['StudSection'] === 'F6' ? 'selected' : '' ?>>F6</option>
                </select></div>

                <label for="StudYear">Year:</label>
                <select class="form-control" id="StudYear" name="StudYear" required>
                    <option value="" <?= isset($d['StudYear']) && $d['StudYear'] === '' ? 'selected' : '' ?>>STUDENT YEAR</option>
                    <option value="FIRST YEAR" <?= isset($d['StudYear']) && $d['StudYear'] === 'F1' ? 'selected' : '' ?>>FIRST YEAR</option>
                    <option value="SECOND YEAR" <?= isset($d['StudYear']) && $d['StudYear'] === 'F2' ? 'selected' : '' ?>>SECOND YEAR</option>
                    <option value="THIRD YEAR" <?= isset($d['StudYear']) && $d['StudYear'] === 'F3' ? 'selected' : '' ?>>THIRD YEAR</option>
                    <option value="FOURTH YEAR" <?= isset($d['StudYear']) && $d['StudYear'] === 'F4' ? 'selected' : '' ?>>FOURTH YEAR</option>
                </select></div>

                <input type="submit" value="Save">
            </form>
        </div>

        <table class="student-table" border="1">
            <tr>
                <th>Name</th>
                <th>Gender</th>
                <th>Course</th>
                <th>Section</th>
                <th>Year</th>
                <th>Action</th>
            </tr>

            <?php foreach ($main as $mainItem): ?>
                <tr>
                    <td><?= $mainItem['StudName'] ?></td>
                    <td><?= $mainItem['StudGender'] ?></td>
                    <td><?= $mainItem['StudCourse'] ?></td>
                    <td><?= $mainItem['StudSection'] ?></td>
                    <td><?= $mainItem['StudYear'] ?></td>
                    <td class="action-links">
                        <a href="delete/<?= $mainItem['id'] ?>">Delete</a>
                        <a href="update/<?= $mainItem['id'] ?>">Edit</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
</body>
</html>

