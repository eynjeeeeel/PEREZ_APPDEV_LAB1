<?php

use App\Controllers\MainController;
use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('test', 'MainController::test');
$routes->post('save', 'MainController::save');
$routes->get('updates', 'MainController::updates');
$routes->get('delete/(:any)', 'MainController::delete/$1');
$routes->get('update/(:any)', 'MainController::update/$1');
//$routes->get('/main/update/(:num)', 'MainController::update/$1');
